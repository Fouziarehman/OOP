            // Multiple Inheritance 
            /*
    A single derived class may inherit from two or more than base classes.
            */
#include<iostream>
using namespace std;
//1st parent class
class Basic  // classroom needs
{
	public:
	int window;
	int door;
	
	void getbasic()
	{
		cout<<"Enter total windows : "<<endl;
		cin>>window;
		cout<<"Enter total doors : "<<endl;
		cin>>door;
	}
	void showbasic()
	{
		cout<<"Windows : "<<window<<endl;
		cout<<"Doors : "<<door<<endl;
	}
};
//2nd parent class
class Function  // function that used as optional
{
	public:
	int fan;
	int light;
	
	void getfunction()
	{
		cout<<"Enter total number of lights : "<<endl;
		cin>>light;
		cout<<"Enter total number of fans : "<<endl;
		cin>>fan;
	}
	void showfunction()
	{
		cout<<"Lights : "<<light<<endl;
		cout<<"Fans : "<<fan<<endl;
	}
};
// child or derived class
class Classroom:public Basic,public Function
{
	public:
    int chair;
    
    void getclassroom()
    {
    	Basic::getbasic();
    	Function::getfunction();
    	cout<<"Enter total number of chairs : "<<endl;
    	cin>>chair;
	}
	void showclassroom()
	{
		Basic::showbasic();
		Function::showfunction();
		cout<<"Chairs : "<<chair<<endl;		
	}
}; 
// main body
int main ()
{
	Classroom clas;
	clas.getclassroom();
	clas.showclassroom();
}

