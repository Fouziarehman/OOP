         // Multi-level Inheritance
         /*
The derived class inherits from a class, which in turn inherits
from some other class.         
         */
#include<iostream>
using namespace std;
         // create parent/base class 
class Student    
{
	public:
	int studentnum;
	char name[20];
	double average;
	
	
Student()          // using constructor
{
	cout<<"Enter your ID / Roll No : "<<endl;
	cin>>studentnum;
	
	cout<<"Enter your Name : "<<endl;
	cin>>name;
	
	cout<<"Enter result average :"<<endl;
	cin>>average;
	}	
	
	void showStudent()
	{
		cout<<"ID : "<<studentnum<<endl;
    	cout<<"Name : "<<name<<endl;	
    	cout<<"Average : "<<average<<endl;
	}


};

                // create child / derived class
class Graduate : public Student
{
	protected:
	int level;
	int year;
	public:
		
		Graduate()          // using constructor
		{
			cout<<"Enter Level :"<<endl;
	cin>>level;
	
	cout<<"Enter Year :"<<endl;
	cin>>year;
		}
		
		void showGraduate()
		
		{
		
		Student::showStudent();
		cout<<"Level : "<<level<<endl;
    	cout<<"Year : "<<year<<endl;
		}
};
          // create 2nd child / derived class
class Master : public Graduate
{
	protected:
	int newID;
	public:
		
		
	Master()         // using constructor
	{
	cout<<"Enter New ID :"<<endl;
	cin>>newID;	
		}
		void showMaster()
		{
			Graduate::showGraduate();
				cout<<"New ID : "<<newID<<endl;
			}	
};

          // main body

int main()
{
	Student std;
	std.showStudent(); 
	// Question no 2 
	Master m;
	m.showMaster();
	
	
}
