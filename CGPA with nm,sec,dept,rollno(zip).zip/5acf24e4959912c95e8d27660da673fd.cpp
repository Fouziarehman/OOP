        // Single Inheritance
/*
A single derived class is inherited from a single base class.
*/
#include<iostream>
using namespace std;
class Info  //  Student Information 
{
	protected:
	int rollno;
	char name[20];
	char sectn[5];
	char deptmt[20];
	
	void getinfo()
	{
		cout<<"Enter your Roll No : "<<endl;
	    cin>>rollno;
	    cout<<"Enter your Name : "<<endl;
	    cin>>name;
	    cout<<"Enter your Section : "<<endl;
	    cin>>sectn;
	    cout<<"Enter your Department : "<<endl;
	    cin>>deptmt;
	}
	void showinfo()
	{
		cout<<"Roll No : "<<rollno<<endl;
		cout<<"Name : "<<name<<endl;
		cout<<"Section : "<<sectn<<endl;
		cout<<"Department : "<<deptmt<<endl;
	}
};
// derived class 
class CGPA:protected Info 
{
	public:
		float mrks1;
		float mrks2;
		float mrks3;
		float mrks4;
		float mrks5;
		float mrks6;
		float mrks7;
		float mrks8;
		int total;
		float per;
		
		void getCGPA()
{
	Info::getinfo();
	cout<<"Enter Quranic Translation CGPA : "<<endl;
	cin>>mrks1;
	
	cout<<"Enter ICT CGPA : "<<endl;
	cin>>mrks2;
	
	cout<<"Enter Calculus CGPA : "<<endl;
	cin>>mrks3;
	
	cout<<"Enter Applied Physics CGPA : "<<endl;
	cin>>mrks4;
	
	cout<<"Enter Programming Fundamental CGPA : "<<endl;
	cin>>mrks5;
	
	cout<<"Enter English CGPA : "<<endl;
	cin>>mrks6;
	
	cout<<"Enter Pak studies CGPA : "<<endl;
	cin>>mrks7;
	
	cout<<"Enter Software Branding CGPA : "<<endl;
	cin>>mrks8;
	
	cout<<"Enter Total CGPA : "<<endl;
	cin>>total;
}
 void showCGPA()
 {
 	Info::showinfo();
 	cout<<"Quranic Translation CGPA : "<<mrks1<<endl;
 	cout<<"ICT CGPA : "<<mrks2<<endl;
 	cout<<"Calculus CGPA : "<<mrks3<<endl;
 	cout<<"Applied Physics CGPA : "<<mrks4<<endl;
 	cout<<"Programming Fundamental CGPA : "<<mrks5<<endl;
 	cout<<"English CGPA : "<<mrks6<<endl;
 	cout<<"Pak studies CGPA : "<<mrks7<<endl;
 	cout<<"Software Branding CGPA : "<<mrks8<<endl;
 	cout<<"Total : "<<total<<endl;
 	per = (mrks1+mrks2+mrks3+mrks4+mrks5+mrks6+mrks7+mrks8)/32;
 	per = per*4;
 	cout<<"Percentage all Subjects : "<<per;
 }
		
};
// main body
int main()
{
	CGPA cgpa;
	cgpa.getCGPA();
	cgpa.showCGPA();
}
